-- Lawn Care Manager schema
-- Run this in the Supabase SQL editor for your project.

create table routes (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

create table clients (
  id uuid primary key default gen_random_uuid(),
  route_id uuid references routes(id) on delete set null,
  name text not null,
  address text,
  price_per_cut numeric(10,2) not null default 0,
  frequency text not null default 'weekly' check (frequency in ('weekly', 'biweekly', 'one_time')),
  notes text,
  created_at timestamptz not null default now()
);

create table cuts (
  id uuid primary key default gen_random_uuid(),
  client_id uuid references clients(id) on delete cascade not null,
  cut_date date not null default current_date,
  status text not null default 'pending' check (status in ('pending', 'done', 'skipped')),
  payment_status text not null default 'unpaid' check (payment_status in ('unpaid', 'paid')),
  created_at timestamptz not null default now()
);

create table todos (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  done boolean not null default false,
  created_at timestamptz not null default now()
);

create table bills (
  id uuid primary key default gen_random_uuid(),
  description text not null,
  amount numeric(10,2) not null default 0,
  due_date date,
  paid boolean not null default false,
  created_at timestamptz not null default now()
);

-- Enable Row Level Security. Since this is a single-user business tool,
-- the simplest policy is "allow all for authenticated users" — tighten
-- later if you add multiple users/logins.
alter table routes enable row level security;
alter table clients enable row level security;
alter table cuts enable row level security;
alter table todos enable row level security;
alter table bills enable row level security;

create policy "Allow all for authenticated users" on routes for all using (auth.role() = 'authenticated');
create policy "Allow all for authenticated users" on clients for all using (auth.role() = 'authenticated');
create policy "Allow all for authenticated users" on cuts for all using (auth.role() = 'authenticated');
create policy "Allow all for authenticated users" on todos for all using (auth.role() = 'authenticated');
create policy "Allow all for authenticated users" on bills for all using (auth.role() = 'authenticated');
