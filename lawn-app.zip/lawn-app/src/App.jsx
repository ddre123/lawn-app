import { Routes, Route, Link } from 'react-router-dom'
import RoutesPage from './pages/RoutesPage.jsx'
import ClientsPage from './pages/ClientsPage.jsx'
import TodoPage from './pages/TodoPage.jsx'
import BillsPage from './pages/BillsPage.jsx'

function App() {
  return (
    <div className="app">
      <header className="app-header">
        <h1>Lawn Care Manager</h1>
        <nav>
          <Link to="/">Routes</Link>
          <Link to="/clients">Clients</Link>
          <Link to="/todo">To-Do</Link>
          <Link to="/bills">Bills</Link>
        </nav>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<RoutesPage />} />
          <Route path="/clients" element={<ClientsPage />} />
          <Route path="/todo" element={<TodoPage />} />
          <Route path="/bills" element={<BillsPage />} />
        </Routes>
      </main>
    </div>
  )
}

export default App
