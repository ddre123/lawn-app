export default function BillsPage() {
  return (
    <div>
      <h2>Business Needs & Bills</h2>
      <p>Track purchases and bills here.</p>
    </div>
  )
}
