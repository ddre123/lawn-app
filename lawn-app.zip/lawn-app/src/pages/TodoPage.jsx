export default function TodoPage() {
  return (
    <div>
      <h2>To-Do</h2>
      <p>Business to-do list goes here.</p>
    </div>
  )
}
