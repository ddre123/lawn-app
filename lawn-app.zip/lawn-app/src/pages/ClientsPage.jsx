export default function ClientsPage() {
  return (
    <div>
      <h2>Clients</h2>
      <p>Client list with price per cut, frequency, cut status, and payment status goes here.</p>
    </div>
  )
}
