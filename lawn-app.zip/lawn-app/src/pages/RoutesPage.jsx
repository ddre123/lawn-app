import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient.js'

export default function RoutesPage() {
  const [routes, setRoutes] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function loadRoutes() {
      const { data, error } = await supabase
        .from('routes')
        .select('*, clients(count)')
        .order('name')
      if (error) console.error(error)
      else setRoutes(data ?? [])
      setLoading(false)
    }
    loadRoutes()
  }, [])

  if (loading) return <p>Loading routes...</p>

  return (
    <div>
      <h2>Routes</h2>
      {routes.length === 0 && <p>No routes yet. Add one in Supabase or build the "add route" form next.</p>}
      <ul>
        {routes.map((r) => (
          <li key={r.id}>{r.name} — {r.clients?.[0]?.count ?? 0} clients</li>
        ))}
      </ul>
    </div>
  )
}
