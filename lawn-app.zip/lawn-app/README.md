# Lawn Care Manager

A mobile-friendly PWA replacing a Notes-app workflow for tracking lawn care
routes, clients, cut/payment status, a to-do list, and business bills.

Stack: React + Vite + Supabase.

## Status

Scaffolded skeleton — routing, Supabase client, and a starting schema are in
place. Pages are placeholders except Routes, which reads from Supabase.
Next step: build out the Clients page (add/edit clients, mark cuts
done/paid) and hook it all up.

## Getting started

```bash
npm install
cp .env.example .env   # fill in your Supabase project URL + anon key
npm run dev
```

## Database

Run `supabase/schema.sql` in your Supabase project's SQL editor to create
the `routes`, `clients`, `cuts`, `todos`, and `bills` tables with RLS
policies enabled.

## Structure

```
src/
  pages/       RoutesPage, ClientsPage, TodoPage, BillsPage
  lib/         supabaseClient.js
  App.jsx      routing shell
supabase/
  schema.sql   database schema
```

## Working with Claude Code

Open this folder in Claude Code and describe what you want built next —
e.g. "add a form to create a new client" or "let me mark a cut as done and
paid from the Clients page." The schema and page stubs give it a starting
point for the whole app.
